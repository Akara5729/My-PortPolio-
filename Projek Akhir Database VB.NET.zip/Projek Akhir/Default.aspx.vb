﻿Imports MySql.Data.MySqlClient
Imports System.Data
Partial Class _Default
    Inherits System.Web.UI.Page



    Protected Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click

        If String.IsNullOrEmpty(txtKodeBuku.Text) OrElse String.IsNullOrEmpty(txtJudul.Text) OrElse String.IsNullOrEmpty(txtPenulis.Text) OrElse String.IsNullOrEmpty(ddlKategori.Text) OrElse String.IsNullOrEmpty(txtJumlah.Text) Then

            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Error: Semua kolom wajib diisi!');", True)
            Return
        End If


        Dim connectionString As String = "server=localhost;user id=root;password=;database=uas"
        Dim query As String = "INSERT INTO tb_buku (kode_buku, judul_buku, penulis, kategori, jumlah) VALUES (@kode, @judul, @penulis, @kategori, @jumlah)"

        Try
            Using con As New MySqlConnection(connectionString)
                Using cmd As New MySqlCommand(query, con)

                    cmd.Parameters.AddWithValue("@kode", txtKodeBuku.Text)
                    cmd.Parameters.AddWithValue("@judul", txtJudul.Text)
                    cmd.Parameters.AddWithValue("@penulis", txtPenulis.Text)
                    cmd.Parameters.AddWithValue("@kategori", ddlKategori.SelectedValue)
                    cmd.Parameters.AddWithValue("@jumlah", CInt(txtJumlah.Text))


                    con.Open()
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Info: Buku baru berhasil disimpan!');", True)


        Catch ex As Exception

            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Error: " & ex.Message.Replace("'", "\'") & "');", True)
        End Try
    End Sub

    Protected Sub ddlKategori_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlKategori.SelectedIndexChanged

    End Sub

    Protected Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

        If String.IsNullOrEmpty(txtKodeBuku.Text) Then
            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Error: Silakan pilih buku yang akan diupdate terlebih dahulu!');", True)
            Return
        End If

        Dim connectionString As String = "server=localhost;user id=root;password=;database=UAS"

        Dim query As String = "UPDATE tb_buku SET judul_buku=@judul, penulis=@penulis, kategori=@kategori, jumlah=@jumlah WHERE kode_buku=@kode"

        Try
            Using con As New MySqlConnection(connectionString)
                Using cmd As New MySqlCommand(query, con)

                    cmd.Parameters.AddWithValue("@judul", txtJudul.Text)
                    cmd.Parameters.AddWithValue("@penulis", txtPenulis.Text)
                    cmd.Parameters.AddWithValue("@kategori", ddlKategori.SelectedValue)
                    cmd.Parameters.AddWithValue("@jumlah", CInt(txtJumlah.Text))


                    cmd.Parameters.AddWithValue("@kode", txtKodeBuku.Text)


                    con.Open()
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Info: Data buku berhasil diupdate!');", True)



        Catch ex As Exception

            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Error: " & ex.Message.Replace("'", "\'") & "');", True)
        End Try
    End Sub


    Protected Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click

        Dim kataKunci As String = txtCari.Text

        Dim connectionString As String = "server=localhost;user id=root;password=;database=UAS"
        Dim query As String = "SELECT kode_buku, judul_buku, penulis, kategori, jumlah FROM tb_buku WHERE kode_buku LIKE @searchTerm"

        Dim dataTable As New DataTable()


        Using con As New MySqlConnection(connectionString)
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.AddWithValue("@searchTerm", "%" & kataKunci & "%")
                Dim dataAdapter As New MySqlDataAdapter(cmd)
                dataAdapter.Fill(dataTable)
            End Using
        End Using

        If dataTable.Rows.Count > 0 Then

            GridViewBuku.DataSource = dataTable

            Dim pesanSukses As String = "Ditemukan " & dataTable.Rows.Count & " buku."
            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('" & pesanSukses & "');", True)
        Else

            GridViewBuku.DataSource = Nothing

            Dim pesanGagal As String = "Buku dengan judul '" & kataKunci & "' tidak ditemukan."
            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('" & pesanGagal.Replace("'", "\'") & "');", True)
        End If


        GridViewBuku.DataBind()
    End Sub

    Protected Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click

        If String.IsNullOrEmpty(txtHapus.Text) Then
            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Error: Silakan pilih buku yang akan dihapus terlebih dahulu!');", True)
            Return
        End If

        Dim connectionString As String = "server=localhost;user id=root;password=;database=UAS"

        Dim query As String = "DELETE FROM tb_buku WHERE kode_buku = @kode"
        Dim koneksi As New MySqlConnection(connectionString)

        Try

            koneksi.Open()

            Using cmd As New MySqlCommand(query, koneksi)

                cmd.Parameters.AddWithValue("@kode", txtHapus.Text)


                cmd.ExecuteNonQuery()
            End Using


            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Info: Data buku berhasil dihapus.');", True)



        Catch ex As Exception

            ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Error: " & ex.Message.Replace("'", "\'") & "');", True)

        Finally

            If koneksi.State = ConnectionState.Open Then
                koneksi.Close()
            End If
        End Try
    End Sub
End Class
