package com.example.uas_202351083;


import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileFragment extends Fragment {

    public ProfileFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        ImageView profileImage = view.findViewById(R.id.profileImage);
        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvNim = view.findViewById(R.id.tvNim);
        TextView tvProdi = view.findViewById(R.id.tvProdi);
        Button btnLogout = view.findViewById(R.id.btnLogout);

        tvName.setText("Pandu Satrio Witjaksono");
        tvNim.setText("202351083");
        tvProdi.setText("Teknik Informatika");
        profileImage.setImageResource(R.drawable.profile_placeholder);

        btnLogout.setOnClickListener(v -> {

            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
            if (getActivity() != null) {
                getActivity().finish();
            }
        });

        return view;
    }
}
