package com.example.uas_202351083;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CalculatorFragment extends Fragment {

    EditText num1, num2;
    Button btnCalculate;
    TextView result;
    String operation = "+";

    public CalculatorFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_calculator, container, false);

        num1 = view.findViewById(R.id.num1);
        num2 = view.findViewById(R.id.num2);
        btnCalculate = view.findViewById(R.id.btnCalculate);
        result = view.findViewById(R.id.result);

        Button btnAdd = view.findViewById(R.id.btnAdd);
        Button btnSubtract = view.findViewById(R.id.btnSubtract);
        Button btnMultiply = view.findViewById(R.id.btnMultiply);
        Button btnDivide = view.findViewById(R.id.btnDivide);

        btnAdd.setOnClickListener(v -> operation = "+");
        btnSubtract.setOnClickListener(v -> operation = "-");
        btnMultiply.setOnClickListener(v -> operation = "x");
        btnDivide.setOnClickListener(v -> operation = "/");

        btnCalculate.setOnClickListener(v -> {
            try {
                double number1 = Double.parseDouble(num1.getText().toString());
                double number2 = Double.parseDouble(num2.getText().toString());
                double res = 0;

                switch (operation) {
                    case "+":
                        res = number1 + number2;
                        break;
                    case "-":
                        res = number1 - number2;
                        break;
                    case "x":
                        res = number1 * number2;
                        break;
                    case "/":
                        if (number2 == 0) {
                            Toast.makeText(getActivity(), "Tidak bisa dibagi dengan 0", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        res = number1 / number2;
                        break;
                }

                result.setText(String.format("Hasil: %.2f", res));
            } catch (NumberFormatException e) {
                Toast.makeText(getActivity(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
