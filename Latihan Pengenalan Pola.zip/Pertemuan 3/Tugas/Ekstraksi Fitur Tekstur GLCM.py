import cv2 #Pandu Satrio Witjaksono (202351083) E
import numpy as np
import matplotlib.pyplot as plt
from skimage.feature import graycomatrix, graycoprops
image = cv2.imread('gray_flower.jpg', cv2.IMREAD_GRAYSCALE) 
glcm = graycomatrix(image, distances=[1], angles=[0], symmetric=True, normed=True)
contrast = graycoprops(glcm, 'contrast')[0, 0] 
dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]  
homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]  
energy = graycoprops(glcm, 'energy')[0, 0]  
correlation = graycoprops(glcm, 'correlation')[0, 0]  
print(f"Contrast: {contrast:.4f}")
print(f"Dissimilarity: {dissimilarity:.4f}")
print(f"Homogeneity: {homogeneity:.4f}")
print(f"Energy: {energy:.4f}")
print(f"Correlation: {correlation:.4f}")
plt.imshow(image, cmap='gray')
plt.title("Gambar Input")
plt.axis("off")
plt.show()
