import numpy as np #Pandu Satrio Witjaksono (202351083) E
from sklearn.decomposition import PCA
X = np.array([
    [2.5, 2.4, 1.8, 2.1],
    [0.5, 0.7, 0.9, 1.2],
    [2.2, 2.9, 2.0, 2.3],
    [1.9, 2.2, 1.6, 1.8],
    [3.1, 3.0, 2.4, 2.9]
])
pca = PCA(n_components=2)        
X_pca = pca.fit_transform(X)       
print("Fitur Asli:\n", X)
print("\nFitur Setelah PCA:\n", X_pca)
print("\nVariansi yang dijelaskan oleh masing-masing komponen:", pca.explained_variance_ratio_)
