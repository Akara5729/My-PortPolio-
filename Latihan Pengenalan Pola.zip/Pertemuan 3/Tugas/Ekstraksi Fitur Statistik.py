import numpy as np #Pandu Satrio Witjaksono (202351083) E
import scipy.stats as stats
data = [165, 170, 168, 175, 160, 172, 178, 180, 167, 169]
mean_value = np.mean(data)
median_value = np.median(data)
variance_value = np.var(data, ddof=1)
std_dev_value = np.std(data, ddof=1)
skewness_value = stats.skew(data)
kurtosis_value = stats.kurtosis(data)
print(f"Mean: {mean_value:.2f}")
print(f"Median: {median_value:.2f}")
print(f"Variance: {variance_value:.2f}")
print(f"Standard Deviation: {std_dev_value:.2f}")
print(f"Skewness: {skewness_value:.2f}")
print(f"Kurtosis: {kurtosis_value:.2f}")
