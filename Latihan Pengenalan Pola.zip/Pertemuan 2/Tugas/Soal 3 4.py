import numpy as np 

# Data nilai ujian 
data = [65, 70, 75, 80, 85, 90, 95] 

# Hitung estimasi parameter
mean_value = np.mean(data) 
variance_value = np.var(data, ddof=0)  # ddof=0 untuk estimasi populasi
std_dev_value = np.std(data, ddof=0) 

print(f"Mean: {mean_value:.2f}") 
print(f"Variance: {variance_value:.2f}") 
print(f"Standard Deviation: {std_dev_value:.2f}")
