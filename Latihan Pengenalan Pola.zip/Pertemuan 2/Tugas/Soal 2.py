import numpy as np 
import matplotlib.pyplot as plt 

# Data acak distribusi normal 
data = np.random.normal(70, 10, 1000) 

# Plot histogram 
plt.hist(data, bins=30, color='skyblue', edgecolor='black') 
plt.title("Histogram Distribusi Normal") 
plt.xlabel("Nilai") 
plt.ylabel("Frekuensi") 
plt.show() 