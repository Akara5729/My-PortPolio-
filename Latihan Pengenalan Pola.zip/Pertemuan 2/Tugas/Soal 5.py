# Probabilitas awal (prior) 
P_Informatika = 0.5 
P_Elektro = 0.5 

# Probabilitas suka matematika dalam masing-masing jurusan 
P_Math_given_Informatika = 0.6 
P_Math_given_Elektro = 0.3 

# Probabilitas total suka matematika 
P_Math = (P_Informatika * P_Math_given_Informatika) + (P_Elektro * P_Math_given_Elektro) 

# Probabilitas mahasiswa dari Informatika jika suka matematika (Teorema Bayes) 
P_Informatika_given_Math = (P_Informatika * P_Math_given_Informatika) / P_Math 

print(f"Probabilitas mahasiswa dari Informatika jika suka matematika: {P_Informatika_given_Math:.2f}") 