# Total bola dalam kantong 
total_bola = 5 + 3 + 2 

# Probabilitas masing-masing warna 
P_merah = 5 / total_bola 
P_biru = 3 / total_bola 
P_hijau = 2 / total_bola 

print(f"Probabilitas bola merah: {P_merah:.2f}") 
print(f"Probabilitas bola biru: {P_biru:.2f}") 
print(f"Probabilitas bola hijau: {P_hijau:.2f}") 