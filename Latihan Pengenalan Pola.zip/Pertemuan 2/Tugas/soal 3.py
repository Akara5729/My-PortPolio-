import random
import collections
import matplotlib.pyplot as plt

# Simulasi pelemparan dadu 1000 kali
n_trials = 1000
outcomes = [random.randint(1, 6) for _ in range(n_trials)]

# Hitung frekuensi setiap angka
freq = collections.Counter(outcomes)

# Hitung probabilitas untuk setiap angka
probabilities = {number: count / n_trials for number, count in freq.items()}

# Visualisasi hasil
plt.bar(probabilities.keys(), probabilities.values(), color='orange')
plt.xticks(range(1, 7))
plt.xlabel("Angka pada Dadu")
plt.ylabel("Probabilitas")
plt.title("Distribusi Pelemparan Dadu 1000 Kali")
plt.ylim(0, 1)  # Set limit y-axis dari 0 hingga 1 untuk probabilitas

# Menambahkan label probabilitas di atas setiap batang
for number, probability in probabilities.items():
    plt.text(number, probability, f'{probability:.2f}', ha='center', va='bottom')

plt.show()