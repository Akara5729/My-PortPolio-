import numpy as np 

# Data jumlah jam belajar dan nilai ujian 
jam_belajar = [2, 3, 5, 7, 9] 
nilai_ujian = [50, 55, 65, 80, 90] 

# Hitung korelasi Pearson 
correlation_matrix = np.corrcoef(jam_belajar, nilai_ujian) 
correlation = correlation_matrix[0, 1] 

print(f"Korelasi antara jam belajar dan nilai ujian: {correlation:.2f}") 