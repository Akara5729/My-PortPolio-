#Nim : 202351083
#Nama : Pandu Satrio Witjaksono
#Kelas : Praktikum Pengenalan Pola (E)
import numpy as np 
import matplotlib.pyplot as plt 
from collections import Counter 

# Data berat badan (sampel dari 50 mahasiswa) 
berat_badan = [60, 55, 58, 62, 70, 65, 68, 72, 74, 69,  
               61, 59, 63, 67, 66, 64, 71, 73, 75, 58, 
               56, 57, 59, 61, 62, 63, 64, 65, 66, 67, 
               60, 58, 57, 59, 55, 56, 67, 69, 70, 72, 
               75, 73, 71, 74, 68, 64, 62, 60, 61, 63] 

# Hitung mean 
mean_value = np.mean(berat_badan)  

# Hitung median 
median_value = np.median(berat_badan)   

# Hitung modus 
modus_value = Counter(berat_badan).most_common(1)[0][0]  

# Hitung variansi 
variance_value = np.var(berat_badan, ddof=1)  

# Hitung standar deviasi 
std_dev_value = np.std(berat_badan, ddof=1)  

# Tampilkan hasil 
print(f"Mean: {mean_value:.2f}") 
print(f"Median: {median_value:.2f}") 
print(f"Modus: {modus_value}") 
print(f"Variance: {variance_value:.2f}") 
print(f"Standard Deviation: {std_dev_value:.2f}") 

# Plot histogram 
plt.hist(berat_badan, bins=10, color='skyblue', edgecolor='black')  
plt.title("Histogram Distribusi Berat Badan Mahasiswa") 
plt.xlabel("Berat Badan (kg)") 
plt.ylabel("Frekuensi") 
plt.show() 