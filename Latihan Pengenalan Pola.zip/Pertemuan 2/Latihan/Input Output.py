# Variabel dan tipe data
nama = "Sabun"  # String
stock = 20       # Integer
harga = 1.500   # Float
is_barang = True  # Boolean

print(nama)
print(stock)
print(harga)
print(is_barang)

nama = input("Nama barang. ")# String
harga = int(input("Masukan Harga. "))
print(f'Saya beli {nama} dengan {harga} rupiah')

# Variabel dan tipe data
nama_barang= "SABUN"  # String
STOCK = 20000       # Integer
HARGA = 1.500   # Float
is_Barang = True  # Boolean

print(nama_barang)
print(STOCK)
print(HARGA)
print(is_Barang)

# Percabangan
nilai = int(input("Nilai anda: "))

if nilai >= 85:
    print("Anda mendapat A.")
else:
    print("Anda tidak mendapat A.")
    
    
for i in range(10):
    print(f"Perulangan ke-{i+5}")

counter = 0
while counter < 20:
    print(f"Counter: {counter}")
    counter += 1




