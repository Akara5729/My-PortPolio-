# Percabangan
nilai = int(input("Nilai anda: "))

if nilai >= 85:
    print("Anda mendapat A.")
else:
    print("Anda tidak mendapat A.")
