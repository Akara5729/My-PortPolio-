def kalkulasi():
    angka1 = float(input("Masukan angka: "))
    angka2 = float(input("Masukan angka: "))
               
    penjumlahan = angka1 + angka2
    pengurangan = angka1 - angka2
    perkalian = angka1 * angka2

    if angka2 != 0:
        pembagian = angka1 / angka2
    else:
        pembagian = "tidak dapat dibagi"

    print(f"Hasil perjumlahan: {penjumlahan}")
    print(f"Hasil pengurangan: {pengurangan}")
    print(f"Hasil perkalian: {perkalian}")
    print(f"Hasil pembagian: {pembagian}")

kalkulasi()

def is_prima(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

angka = int(input("Masukkan sebuah bilangan: "))
if is_prima(angka):
    print(f"{angka} adalah bilangan prima.")
else:
    print(f"{angka} bukan bilangan prima.")
    
    
def fibonacci(n):
    fib_sequence = []
    a, b = 0, 1
    for _ in range(n):
        fib_sequence.append(a)
        a, b = b, a + b
    return fib_sequence

n = int(input("Masukkan jumlah bilangan Fibonacci yang ingin ditampilkan: "))
print(f"Deret Fibonacci hingga {n} bilangan: {fibonacci(n)}")

import numpy as np
print("numpy version" + np.__version__)