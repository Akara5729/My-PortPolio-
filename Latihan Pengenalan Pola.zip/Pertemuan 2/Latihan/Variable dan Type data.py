# Variabel dan tipe data
nama_barang= "SABUN"  # String
STOCK = 20000       # Integer
HARGA = 1.500   # Float
is_Barang = True  # Boolean

print(nama_barang)
print(STOCK)
print(HARGA)
print(is_Barang)
