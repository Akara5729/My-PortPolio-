def hitung_luas_segitiga():
        
    alas = float(input("Luas alas"))
    tinggi = float(input("tinggi segitiga"))
                       
    luas = 0.5 * alas * tinggi
        
    print(f'luas segitiga ={luas}')


hitung_luas_segitiga()