import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.linear_model import Perceptron, LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from matplotlib.colors import ListedColormap

# Load dataset Iris
iris = load_iris()
X = iris.data[:, :2]  # hanya ambil 2 fitur: sepal length dan sepal width
y = iris.target

# Gunakan hanya 2 kelas pertama: Setosa (0) dan Versicolor (1)
X = X[y != 2]
y = y[y != 2]

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1, stratify=y)

# Normalisasi fitur
sc = StandardScaler()
X_train_std = sc.fit_transform(X_train)
X_test_std = sc.transform(X_test)


# ==========================
# 1. Perceptron
# ==========================
ppn = Perceptron(max_iter=1000, eta0=0.1, random_state=1)
ppn.fit(X_train_std, y_train)
y_pred_ppn = ppn.predict(X_test_std)
print("Akurasi Perceptron:", accuracy_score(y_test, y_pred_ppn))
# ==========================
# 2. Logistic Regression
# ==========================
lr = LogisticRegression(C=1.0, random_state=1)
lr.fit(X_train_std, y_train)
y_pred_lr = lr.predict(X_test_std)
print("Akurasi Logistic Regression:", accuracy_score(y_test, y_pred_lr))

# ==========================
# 3. Linear SVM
# ==========================
svm = SVC(kernel='linear', C=1.0, random_state=1)
svm.fit(X_train_std, y_train)
y_pred_svm = svm.predict(X_test_std)
print("Akurasi Linear SVM:", accuracy_score(y_test, y_pred_svm))



# ==========================
# Fungsi visualisasi
# ==========================
def plot_decision_regions(X, y, classifier, title):
    colors = ('red', 'blue')
    cmap = ListedColormap(colors)
    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, 0.02),
                           np.arange(x2_min, x2_max, 0.02))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.3, cmap=cmap)
    plt.scatter(X[:, 0], X[:, 1], c=y, marker='o', cmap=cmap, edgecolor='k')
    plt.xlabel('Sepal length (standar)')
    plt.ylabel('Sepal width (standar)')
    plt.title(title)
    plt.show()

# Plot semua model
#plot_decision_regions(X_train_std, y_train, classifier=ppn, title="Decision Boundary - Perceptron")
#plot_decision_regions(X_train_std, y_train, classifier=lr, title="Decision Boundary - Logistic Regression")
plot_decision_regions(X_train_std, y_train, classifier=svm, title="Decision Boundary - Linear SVM")