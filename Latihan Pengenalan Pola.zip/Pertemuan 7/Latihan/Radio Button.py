from tkinter import *
import tkinter as tk
root = Tk()
root.geometry("300x300")
payment_method_label=Label(root, text="Select Payment Method:")
payment_method = StringVar()
payment_method.set("card")
cards = Radiobutton(root, text="Debit/Credit Card", variable=payment_method,
value="card").pack(anchor=tk.W)
wallet = Radiobutton(root, text="Payment Wallet", variable=payment_method,
value="wallet").pack(anchor=tk.W)
netbanking = Radiobutton(root, text="Net Banking", variable=payment_method, value="net banking").pack(anchor=tk.W)
root.mainloop() 