## Resto APP
Aplikasi ini dibuat untuk memenuhi UAS Praktikum Prodas

### Cara menjalankan
1. Install dependencies terlebih dahulu
```
pip3 install -r requirements.txt
```
2. Jalankan Program
```
python3 resto-app.py
```