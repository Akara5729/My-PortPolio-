CREATE TABLE `kdcustumer` (
  `KdCustomer` varchar(5) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Alamat` varchar(50) NOT NULL,
  `Telp` varchar(15) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kdcustumer`
--

INSERT INTO `kdcustumer` (`KdCustomer`, `Nama`, `Alamat`, `Telp`, `Email`) VALUES
('KC002', 'Iriana', 'Jl. Perkutut no.270 13289', '021421356', 'iriana@yahoo.com'),
('KC003', 'Stefan', 'Jl.Merdeka no.341 77532', '021671234', 'stefan@yahoo.com'),
('KC005', 'Iswanto', 'Jl. Harapan no.34 99980', '021150362', 'iswanto@yahoo.com'),
('KC007', 'Paulus', 'Jl. Krisan no.356 54870', '021781456', 'paulus@yahoo.com'),
('KC008', 'Heri', 'Jl. Durian no.999 321321', '021103478', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kdcustumer`
--
ALTER TABLE `kdcustumer`
  ADD PRIMARY KEY (`KdCustomer`);
COMMIT;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uts_pbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `msbuku`
--

CREATE TABLE `msbuku` (
  `KdBuku` varchar(5) NOT NULL,
  `Judul` varchar(100) NOT NULL,
  `Kata 2` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msbuku`
--

INSERT INTO `msbuku` (`KdBuku`, `Judul`, `Kata 2`) VALUES
('KB002', 'Lord of the Ring : Return Of The King', 'FO'),
('KB008', 'Twins The Empeccable Warrior', 'EHT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `msbuku`
--
ALTER TABLE `msbuku`
  ADD PRIMARY KEY (`KdBuku`);
COMMIT;


CREATE TABLE `new code` (
  `New Code` varchar(5) NOT NULL,
  `Tanggal` varchar(20) NOT NULL,
  `Bulan` varchar(10) NOT NULL,
  `Tahun` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `new code`
--

INSERT INTO `new code` (`New Code`, `Tanggal`, `Bulan`, `Tahun`) VALUES
('300NP', 'Saturday,20', 'January', 2007),
('400PN', 'Sunday, 21', 'January', 2007);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `new code`
--
ALTER TABLE `new code`
  ADD PRIMARY KEY (`New Code`);
COMMIT;

CREATE TABLE `trdetailpeminjaman` (
  `NoPeminjaman` varchar(5) NOT NULL,
  `KdBuku` varchar(5) NOT NULL,
  `Qty` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trdetailpeminjaman`
--

INSERT INTO `trdetailpeminjaman` (`NoPeminjaman`, `KdBuku`, `Qty`) VALUES
('NP001', '', 1),
('NP002', '', 3),
('NP003', 'KB006', 1),
('NP004', 'KB007', 2),
('NP005', 'KB008', 3),
('NP007', 'KB009', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trdetailpeminjaman`
--
ALTER TABLE `trdetailpeminjaman`
  ADD PRIMARY KEY (`NoPeminjaman`);
COMMIT;

CREATE TABLE `trheaderpeminjamandate` (
  `NoPeminjaman` varchar(5) NOT NULL,
  `Tanggal Pinjam` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trheaderpeminjamandate`
--

INSERT INTO `trheaderpeminjamandate` (`NoPeminjaman`, `Tanggal Pinjam`) VALUES
('NP002', '2007-01-18'),
('NP003', '2007-01-20'),
('NP008', '2007-02-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trheaderpeminjamandate`
--
ALTER TABLE `trheaderpeminjamandate`
  ADD PRIMARY KEY (`NoPeminjaman`);
COMMIT;


CREATE TABLE `viewjenis` (
  `JenisBuku` varchar(50) NOT NULL,
  `JumlahBukuPinjam` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `viewjenis`
--

INSERT INTO `viewjenis` (`JenisBuku`, `JumlahBukuPinjam`) VALUES
('Komik berwarna', 5),
('Komik Hitam Putih', 6),
('Novel Asing', 6),
('Novel Indonesia', 4);
COMMIT;

CREATE TABLE `viewpeminjaman` (
  `noPeminjaman` varchar(5) NOT NULL,
  `KdKaryawan` varchar(5) NOT NULL,
  `Nama Karyawan` varchar(100) NOT NULL,
  `KdCustomer` varchar(5) NOT NULL,
  `Nama Customer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `viewpeminjaman`
--

INSERT INTO `viewpeminjaman` (`noPeminjaman`, `KdKaryawan`, `Nama Karyawan`, `KdCustomer`, `Nama Customer`) VALUES
('NP003', 'EN003', 'Johan', 'KC006', 'Rudi Hastono'),
('NP004', 'EN007', 'Saiko', 'KC005', 'Iswanto'),
('NP007', 'EN008', 'Filia', 'KC004', 'Djuandi Then');
COMMIT;

CREATE TABLE `viewpeminjamanjanuary` (
  `NoPeminjaman` varchar(5) NOT NULL,
  `Nama Peminjaman` varchar(50) NOT NULL,
  `Tanggal Peminjaman` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `viewpeminjamanjanuary`
--

INSERT INTO `viewpeminjamanjanuary` (`NoPeminjaman`, `Nama Peminjaman`, `Tanggal Peminjaman`) VALUES
('NP001', 'Heri', '2024-01-01'),
('NP002', 'Paulus', '2024-01-02'),
('NP003', 'Rudi Hastono', '2024-01-03'),
('NP004', 'Iswanto', '2024-01-04'),
('NP005', 'Evalina', '2024-01-05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `viewpeminjamanjanuary`
--
ALTER TABLE `viewpeminjamanjanuary`
  ADD PRIMARY KEY (`NoPeminjaman`);
COMMIT;

--- CREATE VIEW TABEL ---

SELECT *
FROM TrDetailPeminjaman
WHERE 

    HargaSewa BETWEEN 2000 AND 5000
    AND

    Judul LIKE '%o%'
    AND

    NamaCustomer LIKE '%an%'
    AND

    CAST(RIGHT(AlamatKaryawan, 3) AS INT) % 2 = 1;


SELECT 
    KdBuku,
    Judul,
    UPPER(REVERSE(SUBSTRING_INDEX(SUBSTRING_INDEX(Judul, ' ', 2), ' ', -1))) AS 'Kata 2'
FROM 
    TrDetailPeminjaman
WHERE 

    MONTHNAME(TanggalTransaksi) = 'January'
    AND

    EmailCustomer IS NOT NULL AND EmailCustomer <> ''
    AND

    LOCATE(' ', NamaCustomer) = 0
    AND
  
    DATEDIFF(TanggalPeminjaman, '2007-02-20') % 3 = 0
    AND

    (LENGTH(Judul) - LENGTH(REPLACE(Judul, ' ', '')) + 1) >= 3;

SELECT 
    NoPeminjaman, 
    TglPeminjaman
FROM 
    TrDetailPeminjaman
WHERE 

    CHAR_LENGTH(Judul) % 2 = 1
    AND

    Judul LIKE '% %'
    AND

    ((MONTH(TglPeminjaman) * YEAR(TglPeminjaman)) % 
    (CAST(RIGHT(NoPeminjaman, 1) AS INT) + DAY(TglPeminjaman))) IN (6, 7);

SELECT 
 
    CONCAT(
        REVERSE(RIGHT(NoPeminjaman, 3)), 
        REVERSE(LEFT(NoPeminjaman, 2))
    ) AS NewCode,
    

    CONCAT(DATE_FORMAT(TglPeminjaman, '%W'), ' ', DAY(TglPeminjaman)) AS Tanggal,
    

    MONTHNAME(TglPeminjaman) AS Bulan,
    

    YEAR(TglPeminjaman) AS TahunPeminjaman

FROM 
    TrDetailPeminjaman
WHERE 

    (LENGTH(AlamatKaryawan) - LENGTH(REPLACE(AlamatKaryawan, 'n', ''))) >= 2
    AND
 
    LEFT(EmailKaryawan, LOCATE('@', EmailKaryawan) - 1) <>

SELECT * 
FROM MsCustomer
WHERE 
 
    (CAST(RIGHT(KdJenisBuku, 1) AS INT) * HargaSewa) % 3 = 0
    AND
 
    (LOCATE('a', NamaCustomer) * CAST(SUBSTRING(NoTelp, 3, 2) AS INT)) % 2 = 0;

SELECT * 
FROM TrDetailPeminjaman
WHERE 
    -- KdKaryawan bukan 'EN001'
    KdKaryawan <> 'EN001'
    AND
    -- Email tidak kosong
    EmailKaryawan IS NOT NULL AND EmailKaryawan <> ''
    AND
    -- Index dari huruf 'a' pertama di Alamat dikali dengan index huruf 'a' pertama di EmailKaryawan adalah bilangan genap
    (LOCATE('a', Alamat) * LOCATE('a', EmailKaryawan)) % 2 = 0
    AND
    -- NoPeminjaman bukan 'NP005'
    NoPeminjaman <> 'NP005'
    AND
    -- JenisBuku termasuk 'Komik'
    JenisBuku = 'Komik'
ORDER BY 
    NoPeminjaman;

SELECT 
    NoPeminjaman, 
    SUM(Qty) AS QtyPeminjaman
FROM 
    TrDetailPeminjaman
WHERE 
    -- Alamat karyawan mengandung sedikitnya 2 huruf 'a'
    (LENGTH(AlamatKaryawan) - LENGTH(REPLACE(AlamatKaryawan, 'a', ''))) >= 2
    AND
    -- KdCustomer bukan 'KC003'
    KdCustomer <> 'KC003'
    AND
    -- Alamat customer tidak kosong
    AlamatCustomer IS NOT NULL AND AlamatCustomer <> ''
    AND
    -- JenisBuku adalah 'Novel'
    JenisBuku = 'Novel'
    AND
    -- HargaSewa antara 2000 dan 5000
    HargaSewa BETWEEN 2000 AND 5000
GROUP BY 
    NoPeminjaman;

CREATE VIEW ViewPeminjaman AS
SELECT 
    NoPeminjaman, 
    KdKaryawan, 
    NamaKaryawan, 
    KdCustomer, 
    NamaCustomer
FROM 
    TrDetailPeminjaman
WHERE 
    GajiKaryawan BETWEEN 700000 AND 1000000;

CREATE VIEW ViewPeminjamanJanuary AS
SELECT 
    NoPeminjaman, 
    NamaCustomer AS 'Nama Peminjam'
FROM 
    TrDetailPeminjaman
WHERE 
    MONTHNAME(TglPeminjaman) = 'January';

CREATE VIEW ViewJenis AS
SELECT
    JenisBuku,
    SUM(qty_pinjam) AS JumlahBukuPinjam
FROM
    BukuPinjam
WHERE
    JenisBuku NOT IN ('Majalah', 'Tabloid')
GROUP BY
    JenisBuku;


