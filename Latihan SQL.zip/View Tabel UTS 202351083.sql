SELECT *
FROM TrDetailPeminjaman
WHERE 

    HargaSewa BETWEEN 2000 AND 5000
    AND

    Judul LIKE '%o%'
    AND

    NamaCustomer LIKE '%an%'
    AND

    CAST(RIGHT(AlamatKaryawan, 3) AS INT) % 2 = 1;


SELECT 
    KdBuku,
    Judul,
    UPPER(REVERSE(SUBSTRING_INDEX(SUBSTRING_INDEX(Judul, ' ', 2), ' ', -1))) AS 'Kata 2'
FROM 
    TrDetailPeminjaman
WHERE 

    MONTHNAME(TanggalTransaksi) = 'January'
    AND

    EmailCustomer IS NOT NULL AND EmailCustomer <> ''
    AND

    LOCATE(' ', NamaCustomer) = 0
    AND
  
    DATEDIFF(TanggalPeminjaman, '2007-02-20') % 3 = 0
    AND

    (LENGTH(Judul) - LENGTH(REPLACE(Judul, ' ', '')) + 1) >= 3;

SELECT 
    NoPeminjaman, 
    TglPeminjaman
FROM 
    TrDetailPeminjaman
WHERE 

    CHAR_LENGTH(Judul) % 2 = 1
    AND

    Judul LIKE '% %'
    AND

    ((MONTH(TglPeminjaman) * YEAR(TglPeminjaman)) % 
    (CAST(RIGHT(NoPeminjaman, 1) AS INT) + DAY(TglPeminjaman))) IN (6, 7);

SELECT 
 
    CONCAT(
        REVERSE(RIGHT(NoPeminjaman, 3)), 
        REVERSE(LEFT(NoPeminjaman, 2))
    ) AS NewCode,
    

    CONCAT(DATE_FORMAT(TglPeminjaman, '%W'), ' ', DAY(TglPeminjaman)) AS Tanggal,
    

    MONTHNAME(TglPeminjaman) AS Bulan,
    

    YEAR(TglPeminjaman) AS TahunPeminjaman

FROM 
    TrDetailPeminjaman
WHERE 

    (LENGTH(AlamatKaryawan) - LENGTH(REPLACE(AlamatKaryawan, 'n', ''))) >= 2
    AND
 
    LEFT(EmailKaryawan, LOCATE('@', EmailKaryawan) - 1) <>

SELECT * 
FROM MsCustomer
WHERE 
 
    (CAST(RIGHT(KdJenisBuku, 1) AS INT) * HargaSewa) % 3 = 0
    AND
 
    (LOCATE('a', NamaCustomer) * CAST(SUBSTRING(NoTelp, 3, 2) AS INT)) % 2 = 0;

SELECT * 
FROM TrDetailPeminjaman
WHERE 
   
    KdKaryawan <> 'EN001'
    AND
 
    EmailKaryawan IS NOT NULL AND EmailKaryawan <> ''
    AND
 
    (LOCATE('a', Alamat) * LOCATE('a', EmailKaryawan)) % 2 = 0
    AND

    NoPeminjaman <> 'NP005'
    AND
 
    JenisBuku = 'Komik'
ORDER BY 
    NoPeminjaman;

SELECT 
    NoPeminjaman, 
    SUM(Qty) AS QtyPeminjaman
FROM 
    TrDetailPeminjaman
WHERE 
  
    (LENGTH(AlamatKaryawan) - LENGTH(REPLACE(AlamatKaryawan, 'a', ''))) >= 2
    AND
    -- KdCustomer bukan 'KC003'
    KdCustomer <> 'KC003'
    AND

    AlamatCustomer IS NOT NULL AND AlamatCustomer <> ''
    AND

    JenisBuku = 'Novel'
    AND
  
    HargaSewa BETWEEN 2000 AND 5000
GROUP BY 
    NoPeminjaman;

CREATE VIEW ViewPeminjaman AS
SELECT 
    NoPeminjaman, 
    KdKaryawan, 
    NamaKaryawan, 
    KdCustomer, 
    NamaCustomer
FROM 
    TrDetailPeminjaman
WHERE 
    GajiKaryawan BETWEEN 700000 AND 1000000;

CREATE VIEW ViewPeminjamanJanuary AS
SELECT 
    NoPeminjaman, 
    NamaCustomer AS 'Nama Peminjam'
FROM 
    TrDetailPeminjaman
WHERE 
    MONTHNAME(TglPeminjaman) = 'January';

CREATE VIEW ViewJenis AS
SELECT
    JenisBuku,
    SUM(qty_pinjam) AS JumlahBukuPinjam
FROM
    BukuPinjam
WHERE
    JenisBuku NOT IN ('Majalah', 'Tabloid')
GROUP BY
    JenisBuku;


