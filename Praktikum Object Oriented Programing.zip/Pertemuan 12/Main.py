from menu import Makanan, Minuman 
from penjualan import Penjualan 

def main():
    # Daftar menu
    daftar_menu = {
        1: Makanan("Nasi Goreng", 25000),
        2: Makanan("Ayam Bakar", 30000),
        3: Makanan("Sate Ayam", 35000),
        4: Makanan("Rendang", 40000),
        5: Makanan("Gado-Gado", 20000),
        6: Makanan("Mie Goreng", 25000),
        7: Minuman("Es Teh", 5000),
        8: Minuman("Kopi", 15000),
        9: Minuman("Jus Jeruk", 20000),
        10: Minuman("Air Mineral", 3000),
        11: Minuman("Soda", 10000),
        12: Minuman("Teh Botol", 8000)
    }

    penjualan = Penjualan()

    while True:
        # Tampilkan Menu
        print("\n --- Daftar Menu --- ")
        for nomor, menu in daftar_menu.items():
            print(f"{nomor}. {menu.nama} - {(menu.harga)}")

        print("13. Selesai dan checkout")
        print("-----------------------")

        try:
            # Input pilihan user
            pilihan = int(input("Pilih menu (1-13): "))
            if pilihan == 13:
                penjualan.checkout()
                break
            elif pilihan in daftar_menu:
                jumlah = int(input(f"Masukan jumlah untuk {daftar_menu[pilihan].nama}: "))
                penjualan.tambah_item(daftar_menu[pilihan], jumlah)
            else:
                print("Pilihan tidak valid. Silahkan Pilih kembali.")
        except ValueError:
            print("Input tidak valid. Masukan angka.")

if __name__ == "__main__":
    main()