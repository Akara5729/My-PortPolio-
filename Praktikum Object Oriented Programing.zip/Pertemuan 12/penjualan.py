class Penjualan:
    def __init__(self):
        self.keranjang = [] #List untuk menyimpan item yang dibeli
    
    def tambah_item(self, item, jumlah):
        #Menambahkan item ke keranjang belanja
        self.keranjang.append((item, jumlah))
        print(f"{jumlah} x {item.nama} ditambahkan ke keranjang.")
    
    def hitung_total(self):
        #Menghitung total harga sebelum diskon
        total = sum(item.harga * jumlah for item, jumlah in self.keranjang)
        return total
    
    def hitung_diskon(self, total):
        #Menghitung diskon berdasarkan total harga
        if total >= 100000:
            return total * 0.035
        elif total >= 75000:
            return total * 0.03
        elif total >= 50000:
            return total * 0.025
        else:
            return 0 
        
    def checkout(self):
        #Menampilkan total harga, diskon, dan total akhir setelah diskon
        total = self.hitung_total()
        diskon = self.hitung_diskon(total)
        total_akhir = total - diskon
    
        print('\n--- Ringkasan Pembelian ---')
        for item, jumlah in self.keranjang:
            print(f"{jumlah} x {item.nama} (@Rp{item.harga}) = Rp{item.harga * jumlah}")
        print(f"Total Harga : Rp{total}")
        print(f"Diskon: Rp{diskon}")
        print(f"Total Akhir: Rp{total_akhir}")
 