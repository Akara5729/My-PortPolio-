
class kucing:
    #constructor
    def __init__(self, warna, jenis, usia):
        self.warna = warna
        self.jenis = jenis
        self.usia = usia
        
class Mahasiswa:
    #constructor
    def __init__(self,nama,nim,alamat,kucing):
        self.nama = nama
        self.nim = nim
        self.alamat = alamat
        self.kucing = kucing
        
    #membuat Method perkenalan
    
    def perkenalan (self):
        print(f'Perkenalkan nama saya{self.nama} nim {self.nim} asal dari {self.alamat}')
        print(f'Saya juga memiliki kucing berwarna {self.kucing.warna} berjenis {self.kucing.jenis} usia{self.kucing.usia}')
    
#membuat objek
ahmad =Mahasiswa(
    nama=" Ahmad",
    nim='202351099',
    alamat='kudus',
    kucing=kucing(
        warna='hitam',
        jenis='british',
        usia=' 2tahun',
    )
)
ahmad.perkenalan()
        
class Mahasiswa:
    def __init__(self, nama, asal, kucing):
        self.nama = nama 
        self.asal = asal
        self.kucing = kucing
    def perkenalan(self):
        print(f'Perkenalkan saya {self.nama} dari {self.asal}')
        print(f'Saya memiliki Kucing berwarna {self.kucing.warna} berusia{self.kucing.usia}')
        
ahmad = Mahasiswa(
        nama='ahmad',
        asal='rembang',
         kucing=kucing(
        warna='merah',
        jenis='jenis',
        usia='3bulan')


)

ahmad.perkenalan()
      