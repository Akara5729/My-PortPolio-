class Mahasiswa:
    def __init__(self, nama, asal, nim) :
        self.nama = nama
        self.asal = asal
        self.nim = nim 
        
    def perkenalan (self):
        print(f'Perkenalkan saya {self.nama} nim {self.nim} dari {self.asal}')
        

Gufron = Mahasiswa('Gufron','jakarta','202351088')
Ratih = Mahasiswa(asal ='Banten', nim ='202351083', nama = 'Ratih')

#Panggil Method
Gufron.perkenalan()
Ratih.perkenalan()