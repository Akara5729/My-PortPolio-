class Mahasiswa:
    nama=None
    nim=None
    asal=None
    
    def perkenalan (self):
        print(f'perkenalkan nama saya {self.nama} nim {self.nim} asal dari {self.asal}')
#membuat objek

ahmad = Mahasiswa()
ahmad.nama = "Ahmad"
ahmad.nim = "202351089"
ahmad.asal = "rembang"
        
siti = Mahasiswa()
siti.nama = "Siti"
siti.nim = "202351082"
siti.asal = "kudus"
    
ahmad.perkenalan()
siti.perkenalan()