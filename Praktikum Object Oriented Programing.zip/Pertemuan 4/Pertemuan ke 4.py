class kucing :
    #atribute
    warna = None
    jenis = None
    usia = None

#membangun instance/variable sebagai "objet nyata"
kucing1 = kucing()
kucing1.jenis = "Anggora"
kucing1.warna = "Hitam"
kucing1.usia = "3 Tahun"

kucing2 = kucing()
kucing2.jenis = "Persia" 
kucing2.warna = "Oren"
kucing2.usia  = "2 Bulan"

#mencetak Hasil
print(kucing1.jenis, kucing1.warna, kucing1.usia)
print(kucing2.jenis, kucing2.warna, kucing2.usia)


    
