class Mahasiswa:
    nama = None
    nim = None
    asal = None
    
    def perkenalan(self):
        print(f'Perkenalkan, nama saya {self.nama}, NIM {self.nim}, asal dari {self.asal}')

# Membuat objek
ahmad = Mahasiswa()
ahmad.nama = "Ahmad"
ahmad.nim = "202351089"
ahmad.asal = "Rembang"

siti = Mahasiswa()
siti.nama = "Siti"
siti.nim = "202351082"
siti.asal = "Kudus"

# Memanggil metode perkenalan
ahmad.perkenalan()
siti.perkenalan()
