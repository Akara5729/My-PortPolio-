from baju import baju

class pembayaran (baju):
    pass