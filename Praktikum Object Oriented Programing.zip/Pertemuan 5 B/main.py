from baju import baju
from pembayaran import pembayaran
from tokobaju import tokobaju

baju1 = baju('sablon','2000')
baju1.penjualan()

baju2 = pembayaran('nilon', '1000')
baju2.penjualan()

baju3 = tokobaju('katun','4000')
baju3.penjualan()