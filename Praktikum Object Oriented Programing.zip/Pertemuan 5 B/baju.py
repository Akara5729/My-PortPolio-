class baju :
    def __init__(self, jenis, harga):
        self.jenis = jenis
        self.harga = harga
        
    def penjualan (self):
        print(f'baju berjenis {self.jenis}, seharga {self.harga}')
        