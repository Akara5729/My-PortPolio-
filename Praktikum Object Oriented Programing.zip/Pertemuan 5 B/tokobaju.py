from baju import baju

class tokobaju (baju):
    pass