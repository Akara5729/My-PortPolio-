class segitiga:
    def __init__(self, alas, tinggi):
        self.alas = alas
        self.tinggi = tinggi
        self.luas = 0.5 * alas * tinggi
        
segitiga_besar = segitiga(100, 80)
# akses variabel alas, tinggi, dan luas dari luas kelas
print(f'alas: {segitiga_besar.alas}')
print(f'tinggi {segitiga_besar.tinggi}')
print(f'luas: {segitiga_besar.luas}')


alas:100
tinggi:80
luas: 4000.0





