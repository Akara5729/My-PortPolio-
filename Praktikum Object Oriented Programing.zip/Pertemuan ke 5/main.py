from Steam import steam
from PC import PC
from Console import console

godofwar = PC('Godofwar','1000')
godofwar.keterangan()

gta = console('gta','2000')
godofwar.keterangan()

godofwar = steam('AC shadow','3000')
godofwar.keterangan()