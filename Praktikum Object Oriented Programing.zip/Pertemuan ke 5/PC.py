from Steam import steam
class PC (steam):
    pass