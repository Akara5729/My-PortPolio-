class steam :
    
    def __init__(self, nama, harga):
        self.nama = nama 
        self.harga = harga
        
    def keterangan (self):
        print(f'nama game {self.nama} dengan harga {self.harga}')
        