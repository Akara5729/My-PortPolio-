from Steam import steam

class console(steam):
    pass