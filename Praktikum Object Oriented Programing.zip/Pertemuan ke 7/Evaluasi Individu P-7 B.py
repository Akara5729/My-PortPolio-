class Items:
    def interact(self):
        print('interaksi')

class Weapons(Items):
    def interact(self, take, satuan='pcs'):
        super().interact()
        print(f' interaksi -> mengambil {take} {satuan}')
       
class Equipment(Items):  # Changed from main to Items
    def interact(self, equip):
        super().interact()
        print(f' interaksi -> memakai {equip}')
        

# Creating instances of the classes
bow = Items()
sword = Weapons()
armor = Equipment()

# Example interactions
bow.interact()  # Output: interaksi
sword.interact(3)  # Output: interaksi -> mengambil 3 pcs
armor.interact('armor set')  # Output: interaksi -> memakai armor set