class items :
    def interact(self, give, satuan = 'pcs'):
        print(f'Items diberi sebanyak {give} {satuan} ')
class weapon(items):
    def interact(self, take, satuan = 'pcs'):
        super().interact()
        print(f' -> mengambil sebanyak {take} {satuan}')

sword = items()
bow = weapon()

sword.interact(1,'pcs')
bow.interact(1, 'pcs')