class kendaraan:
    def berjalan(self):
        print('berjalan..')

class mobil(kendaraan):
    def berjalan(self, kecepatan, satuan):
        print(f'Berjalan dengan cepat {kecepatan} {satuan}')

sepeda = kendaraan()
sedan = mobil()

sepeda.berjalan()
sedan.berjalan(170, 'km/j')

