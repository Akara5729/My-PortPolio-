class player :
    pass


pemain1 = player()
pemain2 = player()
pemain3 = player();


pemain1.nama = "Bellingham" #atribut
pemain1.posisi = "gelandang"
pemain1.nomor_punggung = 5
pemain1.kecepatan = 89
pemain1.kekuatan =95
pemain1.stamina=98

pemain2.nama = "Wildan"
pemain2.posisi ="gelandang"
pemain2.nomor_punggung = 7
pemain2.kecepatan = 98
pemain2.kekuatan = 91
pemain2.stamina = 98

pemain3.nama = "Adinda"
pemain3.posisi = "penyerang"
pemain3.nomor_punggung = 9
pemain3.kekuatan = 98
pemain3.stamina = 98



print(pemain1) #mengecek apakah adalah object atau tidak
print(pemain1.__dict__) #menampilkann atribut pada object
print(pemain1.nama) #menampilkan salah satu atribut

print("\n nama team\n")

class team:
    pass

team1 = team()

team1.nama = "Real Madrid"
team1.kota = "Madrid"
team1.stadion = "Santiago Bernabeu"

# print(team1)
print(team1)
print(team1.__dict__)


print("\n nama wasit \n")
class  wasit:
    pass

wasit1 = wasit()
wasit2 = wasit()
wasit3 = wasit()

wasit1.nama = "Ridwan"
wasit2.nama = "nabil"
wasit3.nama = "farhan"

print(wasit1)
print(wasit.__dict__)