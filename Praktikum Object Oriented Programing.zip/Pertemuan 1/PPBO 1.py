print("Hello World")
print(0.2)
