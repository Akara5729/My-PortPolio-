x=5
x += 2
x *= 3
x //=2
x**=2
x /=3
print("nilai x sekarang adalah:",x)