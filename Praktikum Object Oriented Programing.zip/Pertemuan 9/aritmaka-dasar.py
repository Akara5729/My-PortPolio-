class angka:
    def __init__(self, angka):
        self.angka = angka
    
    def __add__(self, objek):
        return self.angka + objek.angka
        
x1= angka(20)
x2= angka(10)
print(x1+x2)

class angka:
    def __init__(self, angka):
        self.angka = angka
    
    def __add__(self, objek):
        return angka(
            self.angka + objek.angka)
        
x1= angka(20)
x2= angka(10)
x3 = x1+x2
print(x3.angka)
