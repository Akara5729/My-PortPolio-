class healtpoint:
    def __init__(self, HP):
        self.pemain = HP
        
    @property
    def pemain(self):
        return self.__pemain
    
    @pemain.setter
    def pemain(self,pemain):
        if pemain > 2000:
            self.__pemain = "HP > 2000 adalah type warrior"
        elif pemain < 1000:
            self.__pemain = "HP < 1000 adalah type Catalyst"
        else: 
            self.__pemain = "HP pemain 1000-2000 adalah type Bows"
            
HP = healtpoint(900)

print(f'role pemain dengan {HP.pemain}') 
        