# class mobil :
#     def __init__(self, merk):
#         self.__merk = merk
        
# jip = mobil('jeep')
# print(f'merk: {jip.__merk}')

class mobil:
    def __init__(self, merk):
        self.__merk = merk
        
    def tampilkan_merk(self):
        print(f'merk:{self.__merk}')

jip = mobil('jeep')
#print (f'merk: {jip.__merk}')
jip.tampilkan_merk()
