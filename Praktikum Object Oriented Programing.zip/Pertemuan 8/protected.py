class mobil:
    def __init__(self, merk):
        self._merk = merk
        
        
sedan = mobil('toyota')

#tampikan _merk dari luar kelas

print(f'merk: {sedan._merk}')

#merk: toyota 

class mobil:
    def __init__(self, merk):
        self._merk = merk
        
class mobilbalap(mobil):
    def __init__(self, merk, total_gear):
        super().__init__(merk)
        self._total_gear = total_gear
        
    def pamer(self):
        #akses _merk dari subclass
        print(
            f'ini mobil {self._merk} dengan total gear {self._total_gear}'
        )
#buat objek dari kelas mobilbalap:
ferrari = mobilbalap('ferrari', 8)
ferrari.pamer()
