class mobil:
    def __init__(self, tahun):
        self.tahun = tahun
        
    
    @property
    def tahun(self):
        return self.__tahun

    @tahun.setter
    def tahun(self, tahun):
        if tahun > 2021:
            self.__tahun = 2021
        elif tahun< 1990 :
            self.__tahun = 1990
        else :
            self.__tahun = tahun
        
sedan = mobil(2200)

#tidak error
print(f'mobil ini dibuat tahun {sedan.tahun}')
#error 
# print(f'mobil ini dibuat tahun {sedan.__tahun}')
sedan.tahun = 1800
print(f'mobil ini keluaran {sedan.tahun}')


#_________blackbox___________#
class Mobil:
    def __init__(self, tahun):
        self.tahun = tahun  # This will call the setter

    @property
    def tahun(self):
        return self.__tahun

    @tahun.setter
    def tahun(self, tahun):
        if tahun > 2021:
            self.__tahun = 2021
        elif tahun < 1990:
            self.__tahun = 1990
        else:
            self.__tahun = tahun

# Create an instance of Mobil with a year greater than 2021
sedan = Mobil(2200)

# This will print 2021 as intended
print(f'mobil ini dibuat tahun {sedan.tahun}')

#_________blackbox___________#