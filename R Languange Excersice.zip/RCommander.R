latihan
latihan'
latihan
editDataset(Latihan)
latihan
Latihan
Latihan	
Latihan
Latihan
summary(Latihan)
editDataset(Latihan)
library(rgl, pos=16)
library(nlme, pos=17)
library(mgcv, pos=17)
editDataset(Latihan)
stripchart(Latihan$kom, method="stack", xlab="kom")'
stripchart(Latihan$kom, method="stack", xlab="kom")'

library(lattice, pos=19)
stripchart(Latihan$kom, method="stack", xlab="kom")
editDataset(Latihan)
Boxplot( ~ kom, data=Latihan, id=list(method="y"))Boxplot( ~ kom, data=Latihan, id=list(method="y"))


