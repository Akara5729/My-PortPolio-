#Penerapan Fungsi Lines()
x <- 1:10
y <- x^2

plot(x, y,
     type = "p",
     col = "blue",
     main = "Penerapan Fungsi lines()",
     xlab = "x",
     ylab = "y")

lines(x, y, col = "darkblue", lwd = 2)

#Penerapan Fungsi BoxPlot
data <- list(
  Group1 = rnorm(50, mean = 10, sd = 2),
  Group2 = rnorm(50, mean = 15, sd = 2.5),
  Group3 = rnorm(50, mean = 20, sd = 3)
)

boxplot(data,
        main = "Contoh Fungsi boxplot()",
        col = c("red", "green", "yellow"),
        xlab = "BoxPlot",
        ylab = "Nilai")


#Menerapkan Fungsi Pie
values <- c(30, 35, 10, 20)
labels <- c("A", "B", "C", "D")

pie(values,
    labels = labels,
    main = "Contoh Fungsi pie()",
    col = rainbow(length(values)))

