data <- data.frame(
  class = c("0-9", "10-19", "20-29", "30-39", "40-49", "50-59", "60-69"),
  freq = c(5, 7, 3, 16, 2, 4, 5),
  x = c(4.5, 14.5, 24.5, 34.5, 44.5, 54.5, 64.5),
  fx = c(22.5, 101.5, 73.5, 552, 89, 218, 322.5)
)

print(data)

n <- sum(data$freq)

# mean
mean <- sum(data$fx) / n
print(mean)

# Interval seluruh data
i <- (n + 1) / 2
print(i)

# di temukan interval 21.5
# data ke 21.5 terletak di kelas 30-39
# batas bawah kelas 30-39 adalah 29.5

lo <- 29.5

c <- 39.5 - 29.5
print(c)

# sum frekuensi dari kelas sebelum 30-39
F <- sum(data$freq[1:3])

# frekuensi kelas 30-39
f <- data$freq[4]

median <- lo + c * (((n /2) - F) / f)
print(median)

# modus
# frekuensi kelas ini - frekuensi kelas sebelumnya
b1 <- data$freq[4] - data$freq[3]

# frekuensi kelas ini - frekuensi kelas sesudahnya
b2 <- data$freq[4] - data$freq[5]

modus <- lo + c * (b1 / (b1 + b2))
print(modus)