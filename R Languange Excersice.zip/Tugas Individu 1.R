x <- 202351083
y <-"Pandu Satrio Witjaksono"
z <- "Kelas Praktikum Statistik D"
latihan <-function(name){sprintf ("%s %s %s",x,y,z)}
